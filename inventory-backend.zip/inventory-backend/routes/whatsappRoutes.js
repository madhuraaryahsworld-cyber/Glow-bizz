import express from "express";
import { handleWhatsAppWebhook } from "../controllers/whatsappControllers.js";

const router = express.Router();

router.post("/webhook", handleWhatsAppWebhook);

export default router;
