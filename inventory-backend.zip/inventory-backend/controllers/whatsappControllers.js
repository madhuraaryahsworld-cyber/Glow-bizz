import crypto from "crypto";
import { logWhatsAppEvent } from "../utils/whatsappLogger.js";

const verifySignature = (req) => {
  const signature = req.headers["x-tern-signature"];
  const payload = JSON.stringify(req.body);

  const expected = crypto
    .createHmac("sha256", process.env.TERN_WEBHOOK_SECRET)
    .update(payload)
    .digest("hex");

  return signature === expected;
};

export const handleWhatsAppWebhook = async (req, res) => {
  try {
    //if (!verifySignature(req)) {
     // console.log("❌ Invalid signature");
      //return res.sendStatus(401);
   // }

    console.log("✅ Webhook received:", req.body.type);

    await logWhatsAppEvent(req.body);

    res.sendStatus(200);
  } catch (err) {
    console.error("Webhook Error:", err);
    res.sendStatus(500);
  }
};
